Notes: read files are hard coded in the Library.cpp 

**enter user input in console for both string and choice**

Output format is not exact, a little different

